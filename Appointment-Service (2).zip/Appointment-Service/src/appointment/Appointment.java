package appointment;

import java.util.Date;
import java.util.Objects;

public class Appointment {

    private final String appointmentId;
    private Date appointmentDate;
    private String description;

    public Appointment(String appointmentId, Date appointmentDate, String description) {

        // Validate appointmentId — null and length checked separately
        // so each failure reports its own precise reason.
        if (appointmentId == null) {
            throw new IllegalArgumentException("Appointment ID must not be null.");
        }
        if (appointmentId.length() > 10) {
            throw new IllegalArgumentException("Appointment ID must be 10 characters or fewer.");
        }

        // Validate appointmentDate — null and past checked separately.
        if (appointmentDate == null) {
            throw new IllegalArgumentException("Appointment date must not be null.");
        }
        if (appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date must not be in the past.");
        }

        // Validate description — null and length checked separately.
        if (description == null) {
            throw new IllegalArgumentException("Description must not be null.");
        }
        if (description.length() > 50) {
            throw new IllegalArgumentException("Description must be 50 characters or fewer.");
        }

        this.appointmentId   = appointmentId;
        // Defensive copy so external callers cannot mutate the stored Date.
        this.appointmentDate = new Date(appointmentDate.getTime());
        this.description     = description;
    }

    // Getters
    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getAppointmentDate() {
        // Defensive copy — callers receive a copy, not the internal field.
        return new Date(appointmentDate.getTime());
    }

    public String getDescription() {
        return description;
    }

    // Setters (appointmentId is final — intentionally no setter)
    public void setAppointmentDate(Date appointmentDate) {
        if (appointmentDate == null) {
            throw new IllegalArgumentException("Appointment date must not be null.");
        }
        if (appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date must not be in the past.");
        }
        // Defensive copy on the way in.
        this.appointmentDate = new Date(appointmentDate.getTime());
    }

    public void setDescription(String description) {
        if (description == null) {
            throw new IllegalArgumentException("Description must not be null.");
        }
        if (description.length() > 50) {
            throw new IllegalArgumentException("Description must be 50 characters or fewer.");
        }
        this.description = description;
    }

    // Value-based equality keyed on the unique appointment ID.
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Appointment other = (Appointment) o;
        return Objects.equals(appointmentId, other.appointmentId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(appointmentId);
    }

    @Override
    public String toString() {
        return "Appointment{" +
               "appointmentId='" + appointmentId + '\'' +
               ", appointmentDate=" + appointmentDate +
               ", description='" + description + '\'' +
               '}';
    }
}
