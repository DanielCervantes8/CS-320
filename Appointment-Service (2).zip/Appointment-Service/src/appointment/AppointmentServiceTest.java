package appointment;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class AppointmentServiceTest {

    private AppointmentService service;
    private Date futureDate;

    @BeforeEach
    void setUp() {
        service = new AppointmentService();
        futureDate = new Date(System.currentTimeMillis() + 86_400_000L);
    }

    // -------------------------------------------------------
    // Requirement 1: Add appointments with unique ID
    // -------------------------------------------------------

    @Test
    void testAddAppointmentSuccessfully() {
        Appointment appt = new Appointment("appt01", futureDate, "Annual checkup");
        service.addAppointment(appt);
        // Stronger than assertNotNull — confirms the right appointment is stored.
        assertEquals("appt01", service.getAppointment("appt01").getAppointmentId());
    }

    @Test
    void testAddMultipleAppointmentsWithUniqueIds() {
        Appointment appt1 = new Appointment("appt01", futureDate, "Annual checkup");
        Appointment appt2 = new Appointment("appt02", futureDate, "Follow-up visit");
        service.addAppointment(appt1);
        service.addAppointment(appt2);
        assertEquals("appt01", service.getAppointment("appt01").getAppointmentId());
        assertEquals("appt02", service.getAppointment("appt02").getAppointmentId());
    }

    @Test
    void testAddDuplicateAppointmentIdThrowsException() {
        Appointment appt1 = new Appointment("appt01", futureDate, "Annual checkup");
        Appointment appt2 = new Appointment("appt01", futureDate, "Duplicate attempt");
        service.addAppointment(appt1);
        assertThrows(IllegalArgumentException.class, () ->
            service.addAppointment(appt2)
        );
    }

    @Test
    void testAddNullAppointmentThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
            service.addAppointment(null)
        );
    }

    // -------------------------------------------------------
    // Requirement 2: Delete appointments by ID
    // -------------------------------------------------------

    @Test
    void testDeleteAppointmentSuccessfully() {
        Appointment appt = new Appointment("appt01", futureDate, "Annual checkup");
        service.addAppointment(appt);
        service.deleteAppointment("appt01");
        assertNull(service.getAppointment("appt01"));
    }

    @Test
    void testDeleteNonExistentAppointmentThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
            service.deleteAppointment("doesNotExist")
        );
    }

    @Test
    void testDeleteNullAppointmentIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
            service.deleteAppointment(null)
        );
    }

    @Test
    void testDeleteOneAppointmentLeavesOthersIntact() {
        Appointment appt1 = new Appointment("appt01", futureDate, "Annual checkup");
        Appointment appt2 = new Appointment("appt02", futureDate, "Follow-up visit");
        service.addAppointment(appt1);
        service.addAppointment(appt2);
        service.deleteAppointment("appt01");
        assertNull(service.getAppointment("appt01"));
        assertEquals("appt02", service.getAppointment("appt02").getAppointmentId());
    }
}
