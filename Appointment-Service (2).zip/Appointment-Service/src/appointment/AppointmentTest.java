package appointment;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;
import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;

public class AppointmentTest {

    private Date futureDate;
    private Date pastDate;

    @BeforeEach
    void setUp() {
        // Shared dates created once per test — removes inline boilerplate.
        futureDate = new Date(System.currentTimeMillis() + 86_400_000L);  // +24 hours
        pastDate   = new Date(System.currentTimeMillis() - 86_400_000L);  // -24 hours
    }

    // -------------------------------------------------------
    // Requirement 1: Appointment ID
    //   - Required (not null)
    //   - Max 10 characters
    //   - Not updatable (no setter)
    // -------------------------------------------------------

    @Test
    void testAppointmentIdNullThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment(null, futureDate, "Annual checkup")
        );
    }

    @Test
    void testAppointmentIdTooLongThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("12345678901", futureDate, "Annual checkup")  // 11 chars
        );
    }

    @Test
    void testAppointmentIdExactlyTenCharactersIsAccepted() {
        Appointment appt = new Appointment("1234567890", futureDate, "Annual checkup");
        assertEquals("1234567890", appt.getAppointmentId());
    }

    @Test
    void testAppointmentIdIsNotUpdatable() {
        boolean hasSetterForId = false;
        Method[] methods = Appointment.class.getMethods();
        for (Method method : methods) {
            if (method.getName().equalsIgnoreCase("setAppointmentId")) {
                hasSetterForId = true;
                break;
            }
        }
        assertFalse(hasSetterForId, "Appointment ID should not have a setter.");
    }

    // -------------------------------------------------------
    // Requirement 2: Appointment Date — constructor validation
    // -------------------------------------------------------

    @Test
    void testAppointmentDateNullThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("appt01", null, "Annual checkup")
        );
    }

    @Test
    void testAppointmentDateInPastThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("appt01", pastDate, "Annual checkup")
        );
    }

    @Test
    void testAppointmentDateInFutureIsAccepted() {
        Appointment appt = new Appointment("appt01", futureDate, "Annual checkup");
        assertEquals(futureDate, appt.getAppointmentDate());
    }

    // -------------------------------------------------------
    // Requirement 2: Appointment Date — setter validation
    // -------------------------------------------------------

    @Test
    void testSetAppointmentDateNullThrowsException() {
        Appointment appt = new Appointment("appt01", futureDate, "Annual checkup");
        assertThrows(IllegalArgumentException.class, () ->
            appt.setAppointmentDate(null)
        );
    }

    @Test
    void testSetAppointmentDateInPastThrowsException() {
        Appointment appt = new Appointment("appt01", futureDate, "Annual checkup");
        assertThrows(IllegalArgumentException.class, () ->
            appt.setAppointmentDate(pastDate)
        );
    }

    @Test
    void testSetAppointmentDateValidFutureUpdatesField() {
        Appointment appt = new Appointment("appt01", futureDate, "Annual checkup");
        Date newDate = new Date(System.currentTimeMillis() + 172_800_000L);  // +48 hours
        appt.setAppointmentDate(newDate);
        assertEquals(newDate, appt.getAppointmentDate());
    }

    // -------------------------------------------------------
    // Requirement 3: Description — constructor validation
    // -------------------------------------------------------

    @Test
    void testDescriptionNullThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("appt01", futureDate, null)
        );
    }

    @Test
    void testDescriptionTooLongThrowsException() {
        String tooLong = "A".repeat(51);
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("appt01", futureDate, tooLong)
        );
    }

    @Test
    void testDescriptionExactlyFiftyCharactersIsAccepted() {
        String fiftyChars = "A".repeat(50);
        Appointment appt = new Appointment("appt01", futureDate, fiftyChars);
        assertEquals(fiftyChars, appt.getDescription());
    }

    @Test
    void testDescriptionNormalValueIsStored() {
        Appointment appt = new Appointment("appt01", futureDate, "Annual checkup");
        assertEquals("Annual checkup", appt.getDescription());
    }

    // -------------------------------------------------------
    // Requirement 3: Description — setter validation
    // -------------------------------------------------------

    @Test
    void testSetDescriptionNullThrowsException() {
        Appointment appt = new Appointment("appt01", futureDate, "Annual checkup");
        assertThrows(IllegalArgumentException.class, () ->
            appt.setDescription(null)
        );
    }

    @Test
    void testSetDescriptionTooLongThrowsException() {
        Appointment appt = new Appointment("appt01", futureDate, "Annual checkup");
        String tooLong = "A".repeat(51);
        assertThrows(IllegalArgumentException.class, () ->
            appt.setDescription(tooLong)
        );
    }

    @Test
    void testSetDescriptionExactlyFiftyCharactersIsAccepted() {
        Appointment appt = new Appointment("appt01", futureDate, "Annual checkup");
        String fiftyChars = "A".repeat(50);
        appt.setDescription(fiftyChars);
        assertEquals(fiftyChars, appt.getDescription());
    }

    @Test
    void testSetDescriptionValidValueUpdatesField() {
        Appointment appt = new Appointment("appt01", futureDate, "Annual checkup");
        appt.setDescription("Follow-up visit");
        assertEquals("Follow-up visit", appt.getDescription());
    }

    // -------------------------------------------------------
    // Defensive copy of Date — external mutation must not leak in
    // -------------------------------------------------------

    @Test
    void testGetAppointmentDateReturnsDefensiveCopy() {
        Appointment appt = new Appointment("appt01", futureDate, "Annual checkup");
        Date retrieved = appt.getAppointmentDate();
        long originalTime = retrieved.getTime();
        retrieved.setTime(0L);  // mutate the returned Date
        // Internal field must be unaffected.
        assertEquals(originalTime, appt.getAppointmentDate().getTime());
    }

    // -------------------------------------------------------
    // Valid object construction (positive path)
    // -------------------------------------------------------

    @Test
    void testValidAppointmentCreation() {
        Appointment appt = new Appointment("appt01", futureDate, "Annual checkup");
        assertNotNull(appt);
        assertEquals("appt01",        appt.getAppointmentId());
        assertEquals(futureDate,       appt.getAppointmentDate());
        assertEquals("Annual checkup", appt.getDescription());
    }
}
