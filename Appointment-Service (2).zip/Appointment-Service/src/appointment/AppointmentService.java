package appointment;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {

    private final Map<String, Appointment> appointments = new HashMap<>();

    // Add an appointment — ID must be unique
    public void addAppointment(Appointment appointment) {
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment must not be null.");
        }
        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("An appointment with this ID already exists.");
        }
        appointments.put(appointment.getAppointmentId(), appointment);
    }

    // Delete an appointment by ID
    public void deleteAppointment(String appointmentId) {
        // Dedicated null check produces an accurate message rather than
        // falling through to the not-found branch.
        if (appointmentId == null) {
            throw new IllegalArgumentException("Appointment ID must not be null.");
        }
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("No appointment found with the given ID.");
        }
        appointments.remove(appointmentId);
    }

    // Helper used by tests to look up an appointment
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}
