package Contacts;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    private ContactService contactService;
    private Contact contact;

    @BeforeEach
    void setUp() {
        contactService = new ContactService();
        contact = new Contact("12345", "Daniel", "Cervantes", "1234567890", "123 Main Street");
    }

    // -------------------------------------------------------
    // Requirement 1: Add contacts with unique ID
    // -------------------------------------------------------

    @Test
    void testAddSingleContact() {
        contactService.addContact(contact);
        assertEquals("12345", contactService.getContact("12345").getContactId());
    }

    @Test
    void testAddMultipleContacts() {
        Contact second = new Contact("67890", "John", "Smith", "0987654321", "456 Oak Street");
        contactService.addContact(contact);
        contactService.addContact(second);
        assertEquals("12345", contactService.getContact("12345").getContactId());
        assertEquals("67890", contactService.getContact("67890").getContactId());
    }

    @Test
    void testCannotAddDuplicateContactId() {
        Contact duplicate = new Contact("12345", "Maria", "Garcia", "1112223333", "789 Pine Street");
        contactService.addContact(contact);
        assertThrows(IllegalArgumentException.class, () ->
            contactService.addContact(duplicate)
        );
    }

    @Test
    void testCannotAddNullContact() {
        assertThrows(IllegalArgumentException.class, () ->
            contactService.addContact(null)
        );
    }

    // -------------------------------------------------------
    // Requirement 2: Delete contacts by ID
    // -------------------------------------------------------

    @Test
    void testDeleteContactByContactId() {
        contactService.addContact(contact);
        contactService.deleteContact("12345");
        assertThrows(IllegalArgumentException.class, () ->
            contactService.getContact("12345")
        );
    }

    @Test
    void testCannotDeleteContactThatDoesNotExist() {
        assertThrows(IllegalArgumentException.class, () ->
            contactService.deleteContact("99999")
        );
    }

    @Test
    void testCannotDeleteWithNullId() {
        assertThrows(IllegalArgumentException.class, () ->
            contactService.deleteContact(null)
        );
    }

    @Test
    void testDeleteOneContactLeavesOthersIntact() {
        Contact second = new Contact("67890", "John", "Smith", "0987654321", "456 Oak Street");
        contactService.addContact(contact);
        contactService.addContact(second);
        contactService.deleteContact("12345");
        assertThrows(IllegalArgumentException.class, () ->
            contactService.getContact("12345")
        );
        assertEquals("67890", contactService.getContact("67890").getContactId());
    }

    // -------------------------------------------------------
    // Requirement 3: Update fields by ID
    // -------------------------------------------------------

    @Test
    void testUpdateFirstNameByContactId() {
        contactService.addContact(contact);
        contactService.updateFirstName("12345", "Danny");
        assertEquals("Danny", contactService.getContact("12345").getFirstName());
    }

    @Test
    void testUpdateFirstNameWithNonExistentIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
            contactService.updateFirstName("99999", "Danny")
        );
    }

    @Test
    void testUpdateFirstNameWithInvalidValueThrowsException() {
        contactService.addContact(contact);
        assertThrows(IllegalArgumentException.class, () ->
            contactService.updateFirstName("12345", "Daniel_Long")
        );
    }

    @Test
    void testUpdateLastNameByContactId() {
        contactService.addContact(contact);
        contactService.updateLastName("12345", "Garcia");
        assertEquals("Garcia", contactService.getContact("12345").getLastName());
    }

    @Test
    void testUpdateLastNameWithNonExistentIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
            contactService.updateLastName("99999", "Garcia")
        );
    }

    @Test
    void testUpdateLastNameWithInvalidValueThrowsException() {
        contactService.addContact(contact);
        assertThrows(IllegalArgumentException.class, () ->
            contactService.updateLastName("12345", "Cervantes_X")
        );
    }

    @Test
    void testUpdatePhoneByContactId() {
        contactService.addContact(contact);
        contactService.updatePhone("12345", "2223334444");
        assertEquals("2223334444", contactService.getContact("12345").getPhone());
    }

    @Test
    void testUpdatePhoneWithNonExistentIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
            contactService.updatePhone("99999", "2223334444")
        );
    }

    @Test
    void testUpdatePhoneWithInvalidValueThrowsException() {
        contactService.addContact(contact);
        assertThrows(IllegalArgumentException.class, () ->
            contactService.updatePhone("12345", "12345")
        );
    }

    @Test
    void testUpdateAddressByContactId() {
        contactService.addContact(contact);
        contactService.updateAddress("12345", "456 Oak Street");
        assertEquals("456 Oak Street", contactService.getContact("12345").getAddress());
    }

    @Test
    void testUpdateAddressWithNonExistentIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
            contactService.updateAddress("99999", "456 Oak Street")
        );
    }

    @Test
    void testUpdateAddressWithInvalidValueThrowsException() {
        contactService.addContact(contact);
        assertThrows(IllegalArgumentException.class, () ->
            contactService.updateAddress("12345", "A".repeat(31))
        );
    }
}
