package Contacts;

import java.util.Objects;

public class Contact {

    private final String contactId;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    public Contact(String contactId, String firstName, String lastName, String phone, String address) {

        // contactId — null and length checked separately
        if (contactId == null) {
            throw new IllegalArgumentException("Contact ID cannot be null.");
        }
        if (contactId.length() > 10) {
            throw new IllegalArgumentException("Contact ID cannot be longer than 10 characters.");
        }

        // firstName — null and length checked separately
        if (firstName == null) {
            throw new IllegalArgumentException("First name cannot be null.");
        }
        if (firstName.length() > 10) {
            throw new IllegalArgumentException("First name cannot be longer than 10 characters.");
        }

        // lastName — null and length checked separately
        if (lastName == null) {
            throw new IllegalArgumentException("Last name cannot be null.");
        }
        if (lastName.length() > 10) {
            throw new IllegalArgumentException("Last name cannot be longer than 10 characters.");
        }

        // phone — null and format checked separately
        if (phone == null) {
            throw new IllegalArgumentException("Phone number cannot be null.");
        }
        if (!phone.matches("\\d{10}")) {
            throw new IllegalArgumentException("Phone number must be exactly 10 digits.");
        }

        // address — null and length checked separately
        if (address == null) {
            throw new IllegalArgumentException("Address cannot be null.");
        }
        if (address.length() > 30) {
            throw new IllegalArgumentException("Address cannot be longer than 30 characters.");
        }

        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName  = lastName;
        this.phone     = phone;
        this.address   = address;
    }

    public String getContactId() { return contactId; }
    public String getFirstName()  { return firstName; }
    public String getLastName()   { return lastName; }
    public String getPhone()      { return phone; }
    public String getAddress()    { return address; }

    // contactId is final — intentionally no setter
    public void setFirstName(String firstName) {
        if (firstName == null) {
            throw new IllegalArgumentException("First name cannot be null.");
        }
        if (firstName.length() > 10) {
            throw new IllegalArgumentException("First name cannot be longer than 10 characters.");
        }
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        if (lastName == null) {
            throw new IllegalArgumentException("Last name cannot be null.");
        }
        if (lastName.length() > 10) {
            throw new IllegalArgumentException("Last name cannot be longer than 10 characters.");
        }
        this.lastName = lastName;
    }

    public void setPhone(String phone) {
        if (phone == null) {
            throw new IllegalArgumentException("Phone number cannot be null.");
        }
        if (!phone.matches("\\d{10}")) {
            throw new IllegalArgumentException("Phone number must be exactly 10 digits.");
        }
        this.phone = phone;
    }

    public void setAddress(String address) {
        if (address == null) {
            throw new IllegalArgumentException("Address cannot be null.");
        }
        if (address.length() > 30) {
            throw new IllegalArgumentException("Address cannot be longer than 30 characters.");
        }
        this.address = address;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Contact other = (Contact) o;
        return Objects.equals(contactId, other.contactId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(contactId);
    }

    @Override
    public String toString() {
        return "Contact{contactId='" + contactId + "', firstName='" + firstName +
               "', lastName='" + lastName + "', phone='" + phone +
               "', address='" + address + "'}";
    }
}
