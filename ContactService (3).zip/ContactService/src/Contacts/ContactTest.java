package Contacts;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Method;

public class ContactTest {

    private Contact contact;

    @BeforeEach
    void setUp() {
        contact = new Contact("12345", "Daniel", "Cervantes", "1234567890", "123 Main Street");
    }

    // Requirement 1: Contact ID
    //   - Required (not null), max 10 chars, not updatable

    @Test
    void testContactIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact(null, "Daniel", "Cervantes", "1234567890", "123 Main Street")
        );
    }

    @Test
    void testContactIdCannotBeLongerThanTenCharacters() {
        // 11 characters — must be rejected
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("12345678901", "Daniel", "Cervantes", "1234567890", "123 Main Street")
        );
    }

    @Test
    void testContactIdExactlyTenCharactersIsAccepted() {
        Contact c = new Contact("1234567890", "Daniel", "Cervantes", "1234567890", "123 Main Street");
        assertEquals("1234567890", c.getContactId());
    }

    @Test
    void testContactIdIsNotUpdatable() {
        boolean hasSetter = false;
        for (Method m : Contact.class.getMethods()) {
            if (m.getName().equalsIgnoreCase("setContactId")) {
                hasSetter = true;
                break;
            }
        }
        assertFalse(hasSetter, "Contact ID should not have a setter.");
    }

    // Requirement 2: First Name
    //   - Required (not null), max 10 chars

    @Test
    void testFirstNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("12345", null, "Cervantes", "1234567890", "123 Main Street")
        );
    }

    @Test
    void testFirstNameCannotBeLongerThanTenCharacters() {
        // 11 characters — must be rejected
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("12345", "Daniel_Long", "Cervantes", "1234567890", "123 Main Street")
        );
    }

    @Test
    void testFirstNameExactlyTenCharactersIsAccepted() {
        Contact c = new Contact("12345", "Daniel1234", "Cervantes", "1234567890", "123 Main Street");
        assertEquals("Daniel1234", c.getFirstName());
    }

    @Test
    void testSetFirstNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
            contact.setFirstName(null)
        );
    }

    @Test
    void testSetFirstNameCannotBeLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () ->
            contact.setFirstName("Daniel_Long")
        );
    }

    @Test
    void testSetFirstNameValidValueUpdatesField() {
        contact.setFirstName("Danny");
        assertEquals("Danny", contact.getFirstName());
    }

    // Requirement 3: Last Name
    //   - Required (not null), max 10 chars

    @Test
    void testLastNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("12345", "Daniel", null, "1234567890", "123 Main Street")
        );
    }

    @Test
    void testLastNameCannotBeLongerThanTenCharacters() {
        // 11 characters — must be rejected
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("12345", "Daniel", "Cervantes_X", "1234567890", "123 Main Street")
        );
    }

    @Test
    void testLastNameExactlyTenCharactersIsAccepted() {
        Contact c = new Contact("12345", "Daniel", "Cervantes1", "1234567890", "123 Main Street");
        assertEquals("Cervantes1", c.getLastName());
    }

    @Test
    void testSetLastNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
            contact.setLastName(null)
        );
    }

    @Test
    void testSetLastNameCannotBeLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () ->
            contact.setLastName("Cervantes_X")
        );
    }

    @Test
    void testSetLastNameValidValueUpdatesField() {
        contact.setLastName("Garcia");
        assertEquals("Garcia", contact.getLastName());
    }

    // Requirement 4: Phone
    //   - Required (not null), exactly 10 digits

    @Test
    void testPhoneCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("12345", "Daniel", "Cervantes", null, "123 Main Street")
        );
    }

    @Test
    void testPhoneMustBeExactlyTenDigits() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("12345", "Daniel", "Cervantes", "12345", "123 Main Street")
        );
    }

    @Test
    void testPhoneCannotContainLetters() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("12345", "Daniel", "Cervantes", "12345abcde", "123 Main Street")
        );
    }

    @Test
    void testPhoneExactlyTenDigitsIsAccepted() {
        Contact c = new Contact("12345", "Daniel", "Cervantes", "1234567890", "123 Main Street");
        assertEquals("1234567890", c.getPhone());
    }

    @Test
    void testSetPhoneCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
            contact.setPhone(null)
        );
    }

    @Test
    void testSetPhoneInvalidFormatThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
            contact.setPhone("12345")
        );
    }

    @Test
    void testSetPhoneValidValueUpdatesField() {
        contact.setPhone("9998887777");
        assertEquals("9998887777", contact.getPhone());
    }

    // Requirement 5: Address
    //   - Required (not null), max 30 chars

    @Test
    void testAddressCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("12345", "Daniel", "Cervantes", "1234567890", null)
        );
    }

    @Test
    void testAddressCannotBeLongerThanThirtyCharacters() {
        // 31 characters — must be rejected
        String tooLong = "A".repeat(31);
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("12345", "Daniel", "Cervantes", "1234567890", tooLong)
        );
    }

    @Test
    void testAddressExactlyThirtyCharactersIsAccepted() {
        String thirtyChars = "A".repeat(30);
        Contact c = new Contact("12345", "Daniel", "Cervantes", "1234567890", thirtyChars);
        assertEquals(thirtyChars, c.getAddress());
    }

    @Test
    void testSetAddressCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
            contact.setAddress(null)
        );
    }

    @Test
    void testSetAddressCannotBeLongerThanThirtyCharacters() {
        assertThrows(IllegalArgumentException.class, () ->
            contact.setAddress("A".repeat(31))
        );
    }

    @Test
    void testSetAddressValidValueUpdatesField() {
        contact.setAddress("456 Oak Street");
        assertEquals("456 Oak Street", contact.getAddress());
    }

    // Valid object construction (positive path)

    @Test
    void testContactObjectCreatedSuccessfully() {
        assertNotNull(contact);
        assertEquals("12345",           contact.getContactId());
        assertEquals("Daniel",          contact.getFirstName());
        assertEquals("Cervantes",       contact.getLastName());
        assertEquals("1234567890",      contact.getPhone());
        assertEquals("123 Main Street", contact.getAddress());
    }
    // -------------------------------------------------------
    // equals(), hashCode(), toString() coverage
    // -------------------------------------------------------

    @Test
    void testEqualsSameIdReturnsTrue() {
        Contact c2 = new Contact("12345", "John", "Smith", "0987654321", "456 Oak Street");
        assertEquals(contact, c2);
    }

    @Test
    void testEqualsDifferentIdReturnsFalse() {
        Contact c2 = new Contact("99999", "John", "Smith", "0987654321", "456 Oak Street");
        assertNotEquals(contact, c2);
    }

    @Test
    void testEqualsNullReturnsFalse() {
        assertNotEquals(contact, null);
    }

    @Test
    void testHashCodeSameIdMatches() {
        Contact c2 = new Contact("12345", "John", "Smith", "0987654321", "456 Oak Street");
        assertEquals(contact.hashCode(), c2.hashCode());
    }

    @Test
    void testToStringContainsContactId() {
        assertTrue(contact.toString().contains("12345"));
    }
}
