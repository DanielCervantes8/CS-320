package tasks;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Method;

class TaskTest {

    private Task task;

    @BeforeEach
    void setUp() {
        task = new Task("12345", "Homework", "Complete CS 320 milestone");
    }

    // -------------------------------------------------------
    // Requirement 1: Task ID
    //   - Required (not null), max 10 chars, not updatable
    // -------------------------------------------------------

    @Test
    void testTaskIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
            new Task(null, "Homework", "Complete CS 320 milestone")
        );
    }

    @Test
    void testTaskIdCannotBeLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () ->
            new Task("12345678901", "Homework", "Complete CS 320 milestone")
        );
    }

    @Test
    void testTaskIdExactlyTenCharactersIsAccepted() {
        Task t = new Task("1234567890", "Homework", "Complete CS 320 milestone");
        assertEquals("1234567890", t.getTaskId());
    }

    @Test
    void testTaskIdIsNotUpdatable() {
        boolean hasSetter = false;
        for (Method m : Task.class.getMethods()) {
            if (m.getName().equalsIgnoreCase("setTaskId")) {
                hasSetter = true;
                break;
            }
        }
        assertFalse(hasSetter, "Task ID should not have a setter.");
    }

    // Requirement 2: Name
    //   - Required (not null), max 20 chars

    @Test
    void testNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
            new Task("12345", null, "Complete CS 320 milestone")
        );
    }

    @Test
    void testNameCannotBeLongerThanTwentyCharacters() {
        assertThrows(IllegalArgumentException.class, () ->
            new Task("12345", "A".repeat(21), "Complete CS 320 milestone")
        );
    }

    @Test
    void testNameExactlyTwentyCharactersIsAccepted() {
        String twentyChars = "A".repeat(20);
        Task t = new Task("12345", twentyChars, "Complete CS 320 milestone");
        assertEquals(twentyChars, t.getName());
    }

    @Test
    void testSetNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
            task.setName(null)
        );
    }

    @Test
    void testSetNameCannotBeLongerThanTwentyCharacters() {
        assertThrows(IllegalArgumentException.class, () ->
            task.setName("A".repeat(21))
        );
    }

    @Test
    void testSetNameExactlyTwentyCharactersIsAccepted() {
        String twentyChars = "A".repeat(20);
        task.setName(twentyChars);
        assertEquals(twentyChars, task.getName());
    }

    @Test
    void testSetNameValidValueUpdatesField() {
        task.setName("Project");
        assertEquals("Project", task.getName());
    }

    // -------------------------------------------------------
    // Requirement 3: Description
    //   - Required (not null), max 50 chars
    // -------------------------------------------------------

    @Test
    void testDescriptionCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
            new Task("12345", "Homework", null)
        );
    }

    @Test
    void testDescriptionCannotBeLongerThanFiftyCharacters() {
        assertThrows(IllegalArgumentException.class, () ->
            new Task("12345", "Homework", "A".repeat(51))
        );
    }

    @Test
    void testDescriptionExactlyFiftyCharactersIsAccepted() {
        String fiftyChars = "A".repeat(50);
        Task t = new Task("12345", "Homework", fiftyChars);
        assertEquals(fiftyChars, t.getDescription());
    }

    @Test
    void testSetDescriptionCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
            task.setDescription(null)
        );
    }

    @Test
    void testSetDescriptionCannotBeLongerThanFiftyCharacters() {
        assertThrows(IllegalArgumentException.class, () ->
            task.setDescription("A".repeat(51))
        );
    }

    @Test
    void testSetDescriptionExactlyFiftyCharactersIsAccepted() {
        String fiftyChars = "A".repeat(50);
        task.setDescription(fiftyChars);
        assertEquals(fiftyChars, task.getDescription());
    }

    @Test
    void testSetDescriptionValidValueUpdatesField() {
        task.setDescription("Finish Java unit tests");
        assertEquals("Finish Java unit tests", task.getDescription());
    }

    // -------------------------------------------------------
    // Valid object construction (positive path)
    // -------------------------------------------------------

    @Test
    void testTaskCreation() {
        assertNotNull(task);
        assertEquals("12345",                      task.getTaskId());
        assertEquals("Homework",                   task.getName());
        assertEquals("Complete CS 320 milestone",  task.getDescription());
    }
    // -------------------------------------------------------
    // equals(), hashCode(), toString() coverage
    // -------------------------------------------------------

    @Test
    void testEqualsSameIdReturnsTrue() {
        Task t2 = new Task("12345", "Reading", "Read the module resources");
        assertEquals(task, t2);
    }

    @Test
    void testEqualsDifferentIdReturnsFalse() {
        Task t2 = new Task("99999", "Reading", "Read the module resources");
        assertNotEquals(task, t2);
    }

    @Test
    void testEqualsNullReturnsFalse() {
        assertNotEquals(task, null);
    }

    @Test
    void testHashCodeSameIdMatches() {
        Task t2 = new Task("12345", "Reading", "Read the module resources");
        assertEquals(task.hashCode(), t2.hashCode());
    }

    @Test
    void testToStringContainsTaskId() {
        assertTrue(task.toString().contains("12345"));
    }
}
