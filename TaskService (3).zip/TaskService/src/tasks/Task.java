package tasks;

import java.util.Objects;

public class Task {

    private final String taskId;
    private String name;
    private String description;

    public Task(String taskId, String name, String description) {

        // taskId — null and length checked separately
        if (taskId == null) {
            throw new IllegalArgumentException("Task ID cannot be null.");
        }
        if (taskId.length() > 10) {
            throw new IllegalArgumentException("Task ID cannot be longer than 10 characters.");
        }

        // name — null and length checked separately
        if (name == null) {
            throw new IllegalArgumentException("Task name cannot be null.");
        }
        if (name.length() > 20) {
            throw new IllegalArgumentException("Task name cannot be longer than 20 characters.");
        }

        // description — null and length checked separately
        if (description == null) {
            throw new IllegalArgumentException("Task description cannot be null.");
        }
        if (description.length() > 50) {
            throw new IllegalArgumentException("Task description cannot be longer than 50 characters.");
        }

        this.taskId      = taskId;
        this.name        = name;
        this.description = description;
    }

    public String getTaskId()      { return taskId; }
    public String getName()        { return name; }
    public String getDescription() { return description; }

    // taskId is final — intentionally no setter
    public void setName(String name) {
        if (name == null) {
            throw new IllegalArgumentException("Task name cannot be null.");
        }
        if (name.length() > 20) {
            throw new IllegalArgumentException("Task name cannot be longer than 20 characters.");
        }
        this.name = name;
    }

    public void setDescription(String description) {
        if (description == null) {
            throw new IllegalArgumentException("Task description cannot be null.");
        }
        if (description.length() > 50) {
            throw new IllegalArgumentException("Task description cannot be longer than 50 characters.");
        }
        this.description = description;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Task other = (Task) o;
        return Objects.equals(taskId, other.taskId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(taskId);
    }

    @Override
    public String toString() {
        return "Task{taskId='" + taskId + "', name='" + name +
               "', description='" + description + "'}";
    }
}
