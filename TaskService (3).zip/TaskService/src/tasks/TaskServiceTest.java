package tasks;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TaskServiceTest {

    private TaskService taskService;
    private Task task;

    @BeforeEach
    void setUp() {
        taskService = new TaskService();
        task = new Task("12345", "Homework", "Complete CS 320 milestone");
    }

    // -------------------------------------------------------
    // Requirement 1: Add tasks with unique ID
    // -------------------------------------------------------

    @Test
    void testAddTask() {
        taskService.addTask(task);
        assertEquals("12345", taskService.getTask("12345").getTaskId());
    }

    @Test
    void testAddMultipleTasks() {
        Task second = new Task("67890", "Reading", "Read the module resources");
        taskService.addTask(task);
        taskService.addTask(second);
        assertEquals("12345", taskService.getTask("12345").getTaskId());
        assertEquals("67890", taskService.getTask("67890").getTaskId());
    }

    @Test
    void testCannotAddDuplicateTaskId() {
        Task duplicate = new Task("12345", "Project", "Finish another assignment");
        taskService.addTask(task);
        assertThrows(IllegalArgumentException.class, () ->
            taskService.addTask(duplicate)
        );
    }

    @Test
    void testCannotAddNullTask() {
        assertThrows(IllegalArgumentException.class, () ->
            taskService.addTask(null)
        );
    }

    // -------------------------------------------------------
    // Requirement 2: Delete tasks by ID
    // -------------------------------------------------------

    @Test
    void testDeleteTask() {
        taskService.addTask(task);
        taskService.deleteTask("12345");
        assertThrows(IllegalArgumentException.class, () ->
            taskService.getTask("12345")
        );
    }

    @Test
    void testCannotDeleteTaskThatDoesNotExist() {
        assertThrows(IllegalArgumentException.class, () ->
            taskService.deleteTask("99999")
        );
    }

    @Test
    void testCannotDeleteWithNullId() {
        assertThrows(IllegalArgumentException.class, () ->
            taskService.deleteTask(null)
        );
    }

    @Test
    void testDeleteOneTaskLeavesOthersIntact() {
        Task second = new Task("67890", "Reading", "Read the module resources");
        taskService.addTask(task);
        taskService.addTask(second);
        taskService.deleteTask("12345");
        assertThrows(IllegalArgumentException.class, () ->
            taskService.getTask("12345")
        );
        assertEquals("67890", taskService.getTask("67890").getTaskId());
    }

    // -------------------------------------------------------
    // Requirement 3: Update fields by ID
    // -------------------------------------------------------

    @Test
    void testUpdateName() {
        taskService.addTask(task);
        taskService.updateName("12345", "Project");
        assertEquals("Project", taskService.getTask("12345").getName());
    }

    @Test
    void testUpdateNameWithNonExistentIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
            taskService.updateName("99999", "Project")
        );
    }

    @Test
    void testUpdateNameWithInvalidValueThrowsException() {
        taskService.addTask(task);
        assertThrows(IllegalArgumentException.class, () ->
            taskService.updateName("12345", "A".repeat(21))
        );
    }

    @Test
    void testUpdateDescription() {
        taskService.addTask(task);
        taskService.updateDescription("12345", "Finish Java unit tests");
        assertEquals("Finish Java unit tests", taskService.getTask("12345").getDescription());
    }

    @Test
    void testUpdateDescriptionWithNonExistentIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
            taskService.updateDescription("99999", "Finish Java unit tests")
        );
    }

    @Test
    void testUpdateDescriptionWithInvalidValueThrowsException() {
        taskService.addTask(task);
        assertThrows(IllegalArgumentException.class, () ->
            taskService.updateDescription("12345", "A".repeat(51))
        );
    }
}